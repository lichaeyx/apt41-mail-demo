# Initial Access — 피싱 메일 화면 모의 구현

## 개요
APT41 TOUGHPROGRESS 기반 CHEIRON BAS 프로젝트의 초기 침투(T1566.002) 단계에 사용하는 **교육용 정적 HTML 메일 화면**입니다. 실제 이메일을 발송하지 않으며, 로그인·정보 수집·악성 파일 실행 기능이 없습니다.

## 이번 주 구현 내용
- `index.html`: 발신자, 수신자, 제목, 본문, 캠페인 ID(`APT41-TP-001`) 및 ZIP 다운로드 버튼
- `style.css`: 메일 형태 레이아웃, 버튼 및 반응형 스타일
- `files/sample.zip`: 독립 동작 확인용 무해한 임시 ZIP
- 클릭 시 브라우저에서 임시 ZIP 다운로드 요청

## 파일 구성
```
apt41-mail-demo/
├── README.md
├── index.html
├── style.css
└── files/
    └── sample.zip
```

## 실행 방법
1. 프로젝트 폴더의 `index.html`을 Windows 브라우저에서 엽니다.
2. '실습용 ZIP 다운로드' 버튼을 클릭합니다.
3. `sample.zip` 다운로드 여부를 확인합니다.

로컬 HTTP 서버로 확인하려면 프로젝트 폴더에서 `python -m http.server 8080` 실행 후 `http://localhost:8080/`에 접속합니다.

## 경로 규칙과 다음 주 통합
- 팀 공통 Windows 테스트 작업 경로: `%TEMP%\toughprogress_bas\`
- 현재 `files/sample.zip`은 **프로젝트 내 상대 URL**이며 Windows 작업 경로가 아닙니다.
- 다음 주에는 팀원이 준비한 테스트 ZIP을 웹서버에 올리고 `index.html`의 `href="files/sample.zip"`를 승인된 실습용 HTTP URL로 교체합니다.
- CHEIRON Victim Procedure에서 다운로드 대상 파일을 `%TEMP%\toughprogress_bas\` 하위에 저장하고 SHA-256을 확인합니다. **이 동작은 현재 HTML/CSS에 포함되지 않습니다.**
- HTML의 `download` 속성은 브라우저에 저장을 요청할 뿐 특정 Windows 폴더를 강제로 지정하지 않습니다.

## 확인 항목
- [ ] 메일 화면이 브라우저에서 정상 표시됨
- [ ] 발신자·수신자·제목·본문이 표시됨
- [ ] 다운로드 버튼으로 임시 ZIP을 받을 수 있음
- [ ] 다른 파일 실행 또는 외부 정보 전송이 없음

## 구현 범위 및 제한
이번 주 산출물은 정적 페이지와 임시 ZIP입니다. 실제 이메일 발송, CHEIRON 자동 다운로드, ZIP 해시 검증, 압축 해제 및 LNK 실행은 포함하지 않습니다. 실제 검증을 수행한 환경·날짜·결과는 테스트 후 기록해야 합니다.
